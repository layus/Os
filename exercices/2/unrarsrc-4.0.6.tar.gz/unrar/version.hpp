#define RARVER_MAJOR     4
#define RARVER_MINOR     0
#define RARVER_BETA      6
#define RARVER_DAY       6
#define RARVER_MONTH     2
#define RARVER_YEAR   2011
