#define INCLUDEGLOBAL


#include "rar.hpp"
